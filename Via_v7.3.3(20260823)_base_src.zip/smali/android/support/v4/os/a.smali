.class public interface abstract Landroid/support/v4/os/a;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"

# interfaces
.implements Landroid/os/IInterface;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/os/a$a;
    }
.end annotation


# virtual methods
.method public abstract X(ILandroid/os/Bundle;)V
.end method
