.class public abstract Landroidx/activity/s;
.super Ljava/lang/Object;


# static fields
.field public static a:I = 0x7f0a0095

.field public static b:I = 0x7f0a00ee
