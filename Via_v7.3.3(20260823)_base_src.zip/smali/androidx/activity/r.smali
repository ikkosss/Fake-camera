.class public interface abstract Landroidx/activity/r;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"

# interfaces
.implements Landroidx/lifecycle/h;


# virtual methods
.method public abstract h()Landroidx/activity/OnBackPressedDispatcher;
.end method
