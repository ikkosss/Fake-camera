.class public interface abstract Landroidx/fragment/app/h0;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"


# virtual methods
.method public abstract k(Landroidx/fragment/app/FragmentManager;Landroidx/fragment/app/Fragment;)V
.end method
