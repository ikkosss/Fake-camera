.class public interface abstract Landroidx/fragment/app/FragmentManager$m;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/fragment/app/FragmentManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x609
    name = "m"
.end annotation


# virtual methods
.method public abstract a(Landroidx/activity/b;)V
.end method

.method public abstract b(Landroidx/fragment/app/Fragment;Z)V
.end method

.method public abstract c(Landroidx/fragment/app/Fragment;Z)V
.end method

.method public abstract d()V
.end method

.method public abstract onBackStackChanged()V
.end method
