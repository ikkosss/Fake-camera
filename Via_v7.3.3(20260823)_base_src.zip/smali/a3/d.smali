.class public interface abstract La3/d;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"


# virtual methods
.method public abstract a([Ljava/lang/StackTraceElement;)[Ljava/lang/StackTraceElement;
.end method
