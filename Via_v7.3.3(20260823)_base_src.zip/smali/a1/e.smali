.class public interface abstract La1/e;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"


# virtual methods
.method public abstract a(La1/c;La1/g;)V
.end method
