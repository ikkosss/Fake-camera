.class public La9/r0$g;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"

# interfaces
.implements Lp9/h;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La9/r0;->I3()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public a:Z

.field public final synthetic b:I

.field public final synthetic c:La9/r0;


# direct methods
.method public constructor <init>(La9/r0;I)V
    .locals 0

    .line 1
    iput-object p1, p0, La9/r0$g;->c:La9/r0;

    .line 2
    .line 3
    iput p2, p0, La9/r0$g;->b:I

    .line 4
    .line 5
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 6
    .line 7
    .line 8
    const/4 p1, 0x0

    .line 9
    iput-boolean p1, p0, La9/r0$g;->a:Z

    .line 10
    .line 11
    return-void
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
.end method

.method public static synthetic b(La9/r0$g;Lp9/g;)V
    .locals 0

    .line 1
    iget-object p0, p0, La9/r0$g;->c:La9/r0;

    .line 2
    .line 3
    invoke-static {p0, p1}, La9/r0;->x3(La9/r0;Lp9/g;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
.end method


# virtual methods
.method public a(Lp9/g;)V
    .locals 2

    .line 1
    iget-boolean v0, p0, La9/r0$g;->a:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    goto :goto_0

    .line 6
    :cond_0
    const/4 v0, 0x1

    .line 7
    iput-boolean v0, p0, La9/r0$g;->a:Z

    .line 8
    .line 9
    iget-object v0, p0, La9/r0$g;->c:La9/r0;

    .line 10
    .line 11
    invoke-static {v0}, La9/r0;->v3(La9/r0;)Lp9/o;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    invoke-interface {v0}, Lp9/o;->C()Z

    .line 16
    .line 17
    .line 18
    iget v0, p0, La9/r0$g;->b:I

    .line 19
    .line 20
    iget-object v1, p0, La9/r0$g;->c:La9/r0;

    .line 21
    .line 22
    invoke-static {v1}, La9/r0;->w3(La9/r0;)I

    .line 23
    .line 24
    .line 25
    move-result v1

    .line 26
    if-ne v0, v1, :cond_1

    .line 27
    .line 28
    iget-object v0, p0, La9/r0$g;->c:La9/r0;

    .line 29
    .line 30
    new-instance v1, La9/s0;

    .line 31
    .line 32
    invoke-direct {v1, p0, p1}, La9/s0;-><init>(La9/r0$g;Lp9/g;)V

    .line 33
    .line 34
    .line 35
    invoke-static {v0, v1}, Lz8/h;->d(Landroidx/fragment/app/Fragment;Ljava/lang/Runnable;)V

    .line 36
    .line 37
    .line 38
    :cond_1
    :goto_0
    return-void
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
.end method
