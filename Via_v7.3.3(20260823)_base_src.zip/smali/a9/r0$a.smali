.class public La9/r0$a;
.super Lv5/c;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = La9/r0;->Y2(Lcom/tuyafeng/support/widget/z;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = null
.end annotation


# instance fields
.field public final synthetic c:La9/r0;


# direct methods
.method public constructor <init>(La9/r0;)V
    .locals 0

    .line 1
    iput-object p1, p0, La9/r0$a;->c:La9/r0;

    .line 2
    .line 3
    invoke-direct {p0}, Lv5/c;-><init>()V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
.end method


# virtual methods
.method public a(Landroid/view/View;)V
    .locals 0

    .line 1
    iget-object p1, p0, La9/r0$a;->c:La9/r0;

    .line 2
    .line 3
    invoke-static {p1}, La9/r0;->q3(La9/r0;)V

    .line 4
    .line 5
    .line 6
    return-void
    .line 7
    .line 8
    .line 9
    .line 10
    .line 11
    .line 12
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
.end method
