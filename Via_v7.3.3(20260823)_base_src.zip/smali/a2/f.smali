.class public interface abstract La2/f;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"

# interfaces
.implements Landroid/os/IInterface;


# virtual methods
.method public abstract b()Ljava/lang/String;
.end method

.method public abstract n(Z)Z
.end method
