.class public interface abstract Lab/a;
.super Ljava/lang/Object;
.source "r8-map-id-72e9e9c5589f18e1ed13a69d3e7c73b2e3d9ffd57fb58e63d1f1ce592633c5db"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lab/a$a;
    }
.end annotation


# virtual methods
.method public abstract a(Landroid/content/Context;)V
.end method

.method public abstract b(Landroid/content/Context;)V
.end method

.method public abstract c(Lab/a$a;)V
.end method
